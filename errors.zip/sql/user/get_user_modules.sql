SELECT
	modules.`name` AS module_name
FROM
	users_to_modules
	INNER JOIN
	modules
	ON 
		users_to_modules.module_id = modules.id
WHERE
	users_to_modules.user_id = :user_id
