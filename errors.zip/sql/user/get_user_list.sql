SELECT
id,
status,
IF(DATEDIFF(expires_at, CURRENT_DATE()) > 0, false, true) account_is_expired,
type,
account_number,
email_address,
title,
name,
middle_name,
lastname,
(SELECT name FROM sites WHERE id = site_id) site_name
FROM
users
ORDER BY
name, lastname