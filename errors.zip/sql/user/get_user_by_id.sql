SELECT
id,
status,
IF(DATEDIFF(expires_at, CURRENT_DATE()) > 0, false, true) account_is_expired,
type,
account_number,
email_address,
password,
title,
name,
middle_name,
lastname,
CONCAT(name, if(LENGTH(middle_name) > 0, CONCAT(' ', middle_name, ' '), ' '), lastname) full_name,
avatar_file,
should_change_password,
should_verify_account,
site_id,
(SELECT name FROM sites WHERE id = site_id) site_name,
if (selected_site_id > 0, selected_site_id, site_id) selected_site_id,
(SELECT name FROM sites WHERE id = if(selected_site_id > 0, selected_site_id, site_id)) selected_site_name,
global_admin
FROM
users
WHERE
id= :user_id