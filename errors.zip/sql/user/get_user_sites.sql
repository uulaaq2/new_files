SELECT
	users_to_sites.admin site_admin,
	sites.id AS site_id, 
	sites.`name` AS site_name
FROM
	users_to_sites
	INNER JOIN
	sites
	ON 
		users_to_sites.site_id = sites.id
WHERE
	users_to_sites.user_id = :user_id