SELECT
id site_id,
name site_name
FROM
sites
WHERE
id = :id